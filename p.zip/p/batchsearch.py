import sys
import fileinput
import os
from articles.ArticleSearch import ArticleSearch

# USAGE:
# python batchsearch.py < input.txt
# See example input.txt

artS = ArticleSearch()
params = sys.stdin.readline().strip().split()
filename = '_'.join(params)
while os.path.exists(filename + '.txt'):
    filename += '_'
target = open(filename + '.txt', 'w')
if params[0] == 'OS':
    sb = artS.searchOS
else:
    sb = artS.searchQLS

for line in sys.stdin:
    target.write(line.strip() + '\n-----\n')
    res = artS.rankedSearch(sb, params[1], line.strip(), int(params[2]))
    c = 0
    for sent in res:
        target.write(str(c) +': '+ sent[1][0].encode('utf') + '\n')
        c += 1
        
    target.write('=====\n')

target.close()
# wikipedia-information
this is the course project for ir16 dd2476 (search engine and information retrieval systems) in kth.

A tool that gives context information about a search string using wikipedia.

project link: https://www.kth.se/social/files/56ec78faf276546aed77fa85/project8.pdf

features
--------

* fetch relevant wikipedia pages
* text summarization

installation & dependencies
--------

* python 2.7.10
* summa (for text summarization) - https://github.com/summanlp/textrank
* beautifulsoup (for xml content extraction) - https://www.crummy.com/software/BeautifulSoup/
* flask (web framework) - http://flask.pocoo.org/
* nltk (natural language framework - for the tokenization and other possible manipulations) - http://www.nltk.org/

use guide
--------

* type in the search string
* type in the number of document you want to show on the screen
* and everything is done.
* you can modify parameters in _updateGenerator_ and _matchingGenerator_
(some front-end work need to be done in the future)

Article search algorithm 2
--------
* Based on how uncommon words in the query are in the English language (given by "en.txt").
* Each word is scored by log(N/wc) where N is the total number of word counts in "en.txt" and wc is the wordcount for the given word
* params: maxNumArtPer, termScale, tresh, descScale, minScore, searchAllWords
* score for an an article is calculated as (termScale / (1 + c * descScale)) x sum(score for each word in the query string that led to the article), c goes from 0 to maxNumArtPer -1 and corresponds to the ranking wikipedia gives the articles for the given query string.

Algorithm procedure:
--------
* If searchAllWords: Make an initial search for each word in query string
* make a search using the complete query string, rank resulting articles.
* split the query string at the words with score <= min(word score in query) + tresh
* search using each substring
* repeat until split query string is empty

Example:
--------
* query string: "Apartheid in South Africa"
* search("Apartheid in South Africa"), score returned articles using "Apartheid in South Africa"
* split at most common word, we the get: "Apartheid" and "South Africa"
* search("Apartheid"), score returned articles using "Apartheid", search("South Africa"), score returned articles using "South Africa"
* split, we get "Apartheid" and "Africa"
* search("Africa") and score using "Africa", ("Apartheid" already searched)
* split does not give any new query strings so we are done
* return list of articles ordered by descending scores

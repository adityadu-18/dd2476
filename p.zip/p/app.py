from flask import Flask, render_template, request, redirect
from articles.ArticleSearch import ArticleSearch
from Indexer import Indexer
from index.Query import Query
from time import time
from operator import itemgetter
from itertools import groupby, combinations, permutations

app = Flask(__name__)

@app.route('/')
def index():
	return render_template('index.html')


@app.route('/search')
def search():

	# Get the search terms or an empty string if they can't be found
	search_terms = request.args.get('terms', '')

	# Redirect to the home page of there is no search term (an empty string)
	if search_terms == "":
		return redirect('/')

	# Compute the results (and the time elapsed)
	start_time = time()
	article_searcher = ArticleSearch()

	search_backend, search_algorithm, max_num_articles, exclude_search_term, article_ranking = get_search_params(article_searcher)
	search_results = article_searcher.rankedSearch(search_backend, search_algorithm, search_terms, max_num_articles)

	indexer = Indexer(search_results)
	indexer.buildIndexes() 

	if article_ranking:
	    query = Query(search_terms.split())
	    indexer_search_result = indexer.search(query, articleRanking=True).viewitems()
	    blob = []
	    for articleName, result in indexer_search_result:
		for idx, score in result:
		    blob.append((indexer.getContent(articleName)[idx[0]][idx[1]], score))
		# print(str(result[0][0]) + " with score: " + str(result[0][1])) # Sentence id of the best sentence
		#print(" " + indexer.getContent(articleName)[result[0][0][0]][result[0][0][1]]) # Best Sentence
	    blob.sort(key=lambda tup: tup[1], reverse=True)
	    number_of_articles = len(search_results)
	    search_results = map(lambda tup: tup[0], blob[:4 * number_of_articles])
	else:
	    search_results = in_article_search(search_terms, search_results, indexer, exclude_search_term)
	end_time = time()
	time_elapsed = end_time - start_time

	# Render the results
	# NOTE: Of course, we still have to discuss about what to display exactly
	return render_template('search.html', search_terms=search_terms, search_results=search_results, time_elapsed=time_elapsed, article_ranking=article_ranking)

# Tries to read search parameters. Returns default values if parameters missing
# or incorrect.
def get_search_params(article_searcher):
    backends = {'OS': article_searcher.searchOS, 'QLS': article_searcher.searchQLS}
    requested_backend = request.args.get('search-backend', 'OS')
    if requested_backend in backends:
	search_backend = backends[requested_backend]
    else:
	search_backend = backends['OS']

    algorithms = ['O', 'Y']
    requested_algorithm = request.args.get('search-algorithm', 'O')
    if requested_algorithm in algorithms:
	search_algorithm = requested_algorithm
    else:
	search_algorithm = 'O'

    # Try to get max number of articles per term from user, default to 2
    try:
	max_num_articles = int(request.args.get('max-articles-per-term', 2))
    except ValueError:
	max_num_articles = 2

    exclude_search_term = True if request.args.get('exclude-term', 'False') == 'True' else False
    article_ranking = True if request.args.get('article-ranking', 'False') == 'True' else False

    return search_backend, search_algorithm, max_num_articles, exclude_search_term, article_ranking

def in_article_search(search_terms, search_results, indexer, exclude_search_term = False):

    # Create a dict of results to easier combine initial search with 'in article' search.
    dict_results = {k: list(v)[0][1::] for k, v in groupby(search_results, key=lambda x: x[0])}

    for title, index in indexer.indexes.viewitems():
	terms_and_sentences = []

	# Don't search in the article for the term that was used to find the article.
	used_term = dict_results[title][0][2]
	uniwords = [x for x in search_terms.split() if x != used_term] if exclude_search_term else search_terms.split()
	biwords = map(lambda x: ' '.join(x), list(combinations(uniwords, 2)))
	search_strings = uniwords + biwords

	for term in search_strings:
	    query = Query(term.split(" "))
	    res = index.search(query)
	    if not res:
		#print 'empty result'
		pass
	    else:
		# Add top 3 best sentences.
		best_query_id = ((res[0])[0])
		best_something = res[:3]
		best_ids = [x[0] for x in best_something]
		best_sentences = [index.content[best_query_id[0]][best_query_id[1]] for best_query_id in best_ids]
		terms_and_sentences += best_sentences
	dict_results[title] += (remove_duplicates(terms_and_sentences),)

    search_results = dict_results.items()
    search_results.sort(key=lambda x: x[1][0][1], reverse=True)
    return search_results

def remove_duplicates(seq):
    seen = set()
    seen_add = seen.add
    return [x for x in seq if not (x in seen or seen_add(x))]

if __name__ == "__main__":
    app.run(debug=True, port=8000)

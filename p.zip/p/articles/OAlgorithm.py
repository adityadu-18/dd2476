import os
import re
import math
from FrequencyTools import Frequency
from operator import itemgetter


class OAlgorithm:

    def __init__(self):
        self.freq = Frequency(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '../en.txt'))

    # Retrieves a list of ranked articles. Uses word frequency to score articles
    # maxNumOfArtPer: the number of articles retrieved per valid search on wikipedia
    # termScale: Scale term score when deciding score for a substring
    # tresh: When removing words, removes words with score < min score + tresh
    # descScale: multiply the score of descending articles from a wikipedia search by 1/(1 + c * descScale), where c = 0,..,maxNumOfArtPe - 1
    # minScore: Only search if score > minScore
    # searchAllWords: If true makes an initial search for each word in the
    # query string
    def rankedSearch(self, searchBackend, searchString, maxNumOfArtPerSearch, termScale=1.0, tresh=0.0, descScale=0.2, minScore=5.0, searchAllWords=True):
        scoredArts = {}
        searchedStrings = set()
        splitSeachString = searchString.split()
        # Get a score for each word to be able to determine where to split the
        # query string
        scoreList = [self.scoreString(word, 1.0) for word in splitSeachString]
        delims = ''
        subStrings = re.split(delims, searchString)
        # Search all words in query
        if searchAllWords:
            for word in splitSeachString:
                searchedStrings.add(word)
                scoredArts = self.searchSubstring(
                    searchBackend, word, scoredArts, maxNumOfArtPerSearch, termScale, descScale, minScore)

        # Make a search using the whole query string, then split and search
        # substrings until split gives empty strings
        while len(''.join(subStrings).split()) > 0:
            for subString in subStrings:
                subString = subString.strip()
                if subString not in searchedStrings:
                    scoredArts = self.searchSubstring(searchBackend, subString, scoredArts, maxNumOfArtPerSearch, termScale, descScale, minScore)
                    searchedStrings.add(subString)

            # Add word with the lowest score to the set of words where to split
            # the query string
            remIndx = self.getIndexesToRemove(scoreList, tresh)
            for i, j in enumerate(remIndx):
                delims += '\\b' + splitSeachString[j] + '\\b|'
                scoreList[j - i] = float('inf')
            subStrings = re.split(r'%s' % delims, searchString)

        return sorted(scoredArts.items(), key=lambda k: k[1][1], reverse=True)

    def searchSubstring(self, searchBackend, subString, scoredArts, maxNumOfArtPerSearch, termScale, descScale, minScore):
        if (len(subString.split()) > 0):
            score = self.scoreString(subString, termScale)
            if (score > minScore):
                searchRes = searchBackend(subString, maxNumOfArtPerSearch)
                c = 0
                for res in searchRes:
                    if (res[0] not in scoredArts) or (score > scoredArts[res[0]][1]):
                        scoredArts[res[0]] = [res[1], (1.0 / (1.0 + c * descScale)) * score, subString]
                    c += 1

        return scoredArts

    def getIndexesToRemove(self, scoreArr, tresh):
        indexOut = []
        minIdx = min(enumerate(scoreArr), key=itemgetter(1))[0]
        for i in range(len(scoreArr)):
            if scoreArr[i] - tresh <= scoreArr[minIdx]:
                indexOut.append(i)

        return indexOut

    def scoreString(self, searchString, termScale):
        score = 0
        for word in searchString.split():
            score += termScale * math.log(self.freq.getN() / (1 + self.freq.getWordFreq(word.lower())))
        return score

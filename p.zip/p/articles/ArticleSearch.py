import json
import os
import urllib2
import urllib
import re
from bs4 import BeautifulSoup
from OAlgorithm import OAlgorithm
from YAlgorithm import YAlgorithm


class ArticleSearch:

    def __init__(self):
        self.apiURL = 'https://en.wikipedia.org/w/api.php?'
        self.OAlg = OAlgorithm()
        self.YAlg = YAlgorithm()

    def searchOS(self, searchString, maxNumOfArticles):
        res = []
        request = urllib2.urlopen(self.apiURL + 'action=opensearch&format=json&search=' + 
            urllib.quote_plus(searchString) + '&limit=' + str(maxNumOfArticles) + '&redirects=resolve')
        jsonObject = json.loads(request.read())
        for i in range(len(jsonObject[1])):
            if jsonObject[2][i][-13:] != 'may refer to:':
                res.append([jsonObject[1][i], jsonObject[2][i]])
        return res
        
    # Set inTitle to True to search only in article titles
    def searchQLS(self, searchString, maxNumOfArticles, inTitle=False):
        inTitleStr = 'intitle%3A' if inTitle else ''
        searchString = inTitleStr + urllib.quote_plus(searchString)
        res = []
        request = urllib2.urlopen(self.apiURL + 'action=query&format=json&redirects=1&list=search&srsearch='+searchString + '&srlimit=' + str(maxNumOfArticles))
        jsonObject = json.loads(request.read())
        for art in jsonObject['query']['search']:
            htmlObject = BeautifulSoup(art['snippet'], 'html.parser')
            res.append([art['title'],htmlObject.getText()])
        return res

    # searchBackend: searchOS or searchQLS
    # searchAlgoritm: 'O' or 'Y'
    # searchString
    # maxNumOfArticlesPerSearch
    def rankedSearch(self, searchBackend, searchAlgorithm, searchString, maxNumOfArticlesPerSearch):
        searchString = self.preProcessSearchString(searchString)
        if searchAlgorithm == 'O':
            return self.OAlg.rankedSearch(searchBackend, searchString, maxNumOfArticlesPerSearch)
        elif searchAlgorithm == 'Y':
            return self.YAlg.rankedSearch(searchBackend, searchString, maxNumOfArticlesPerSearch)
        else:
            raise Exception('Unsupported parameters')            
        
    # Remove non alpha-numerical characters and make sure there are only one space between words.
    def preProcessSearchString(self, searchString):
        return ' '.join(re.sub(r'[^0-9a-zA-Z]',r' ', searchString).split())


class Frequency:

    def __init__(self, wfFileName):
        self.freqDict = {}
        self.N = 0
        f = open(wfFileName, 'r')
        for line in f:
            splLine = (line.strip()).split()
            self.freqDict[splLine[0]] = int(splLine[1])
            self.N += int(splLine[1])

    # Returns the number of views an article had during given timeperiod, thows urllib2.HTTPError if page not found
    # example usage wikipedia: getPageViews('en.wikipedia.org','Albert Einstein','20150511','20160511')
    # example usage wiktionary: getPageViews('en.wiktionary.org','functional','20150511','20160511')
    def getPageViews(self, wikiproject, title, start, end):
        response = urllib2.urlopen('https://wikimedia.org/api/rest_v1/metrics/pageviews/per-article/' + wikiproject + '/all-access/all-agents/' + urllib.quote(title.encode('utf8')) + '/daily/' + start + '/' + end)
        jsonRes = json.loads(response.read())
        views = 0
        for d in jsonRes['items']:
            views += d['views']

        return views

    def getWordFreq(self, word):
        return self.freqDict[word] if word in self.freqDict else 0

    def getN(self):
        return self.N

import json
import urllib
import urllib2
import nltk
from nltk.tokenize.regexp import RegexpTokenizer
from bs4 import BeautifulSoup


class ArticleFetcher:

    # intro: True or False: returns intro section of article
    # explaintext: content as plaintext instead of html
    # maxs: integer: max number of sentences to return
    # returnform: return format as given by media wiki eg. xml, json, ...

    @staticmethod
    def getArticle(articleTitle, intro, explaintext, maxs, returnformat):
        titleStr = urllib.urlencode({'titles': articleTitle.encode('utf8')})
        introStr = ''
        explainStr = ''
        maxsStr = ''
        if intro:
            introStr += '&exintro=1'
        if explaintext:
            explainStr += '&explaintext=1'
        if maxs != -1:
            maxsStr += '&exsentences=' + str(maxs)

        response = urllib2.urlopen('https://en.wikipedia.org/w/api.php?format=' + returnformat + '&action=query&prop=extracts' + explainStr + '&' + titleStr + '&redirects=true' + introStr + maxsStr)

        return response.read()

    @staticmethod
    def parseArticle(article, articleformat='json'):
        if articleformat == 'json':
            jsonObject = json.loads(article)
            firstPageId = jsonObject['query']['pages'].keys()[0]
            page = jsonObject['query']['pages'][firstPageId]
            retList = [[page['title']]]
            extract = ArticleFetcher.parseHtml(page['extract'])
            retList.extend(extract)
            return retList
        else:
            raise Exception('Unsupported article format')
            
    @staticmethod
    def getWordsCountInLinks(articleTitle):
        wordTolinkCount = {}
        titleStr = urllib.urlencode({'titles': articleTitle.encode('utf8')})
        continueStr = ''
        urlString = 'https://en.wikipedia.org/w/api.php?format=json&action=query&prop=links&'+ titleStr + '&pllimit=500'
        doContinue = True
        tokenizer = RegexpTokenizer(r'\W+', gaps=True)
        while (doContinue):
            request = urllib2.urlopen(urlString + continueStr)
            jsonObject = json.loads(request.read())
            firstPageId = jsonObject['query']['pages'].keys()[0]
            links = jsonObject['query']['pages'][firstPageId]['links']
            for link in links:
                for word in tokenizer.tokenize(link['title']):
                    if word.lower() in wordTolinkCount:
                        wordTolinkCount[word.lower()] += 1
                    else:
                        wordTolinkCount[word.lower()] = 1
            if 'continue' in jsonObject:
                continueStr = '&' + urllib.urlencode({'plcontinue': jsonObject['continue']['plcontinue'].encode('utf8')})
            else:
                doContinue = False  
        
        return wordTolinkCount 
        

    @staticmethod
    def parseHtml(htmlString):
        tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')
        phrases = []
        htmlObject = BeautifulSoup(htmlString, 'html.parser')
        for phrase in htmlObject.find_all('p'):
            phrases.append(tokenizer.tokenize(phrase.getText()))
        return phrases
        
    @staticmethod
    def getParsedArticle(articleTitle):
        try:
            return ArticleFetcher.parseArticle(ArticleFetcher.getArticle(articleTitle, False, False, -1, 'json'),'json')
        except Exception as e:
            print(e)
            return ['Error fetching article']

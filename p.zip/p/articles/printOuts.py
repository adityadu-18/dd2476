import sys
from ArticleSearch import ArticleSearch

artS = ArticleSearch()
# use artS.searchQLS or artS.searchOS as search backend
# arg 1: 'O' or 'Y' to choose algorithm
# arg 2: query string
# arg 3: number of articles retrieved per search hit
if len(sys.argv) == 4:
    print 'Query: ' +  sys.argv[2]
    
    results = artS.rankedSearch(artS.searchQLS, sys.argv[1], sys.argv[2], int(sys.argv[3]))
    for article in results:
        print article[1][2] + ' --> ' + article[0] + ' score: ' + str(article[1][1]) + '\n'
import operator
import math

class YAlgorithm:

    class scoreDict(dict):
    
        def __init__(self, YAlgorithm):
            self.YA = YAlgorithm

        def updateByPages(self, pages, weight):
            k = len(pages)
            for i in range(k):
                if self.has_key(pages[i]):
                    self[pages[i]] += float(weight) * (1 - float(i) / float(k))
                else:
                    self[pages[i]] = float(weight) * (1 - float(i) / float(k))  # param

        def appendByPages(self, searchWords, numDocuments):
            if len(searchWords) == 1:
                return  # one word, do nothing
            elif len(searchWords) > 2:
                self.append(searchWords, numDocuments, bigram=True)
            self.append(searchWords, numDocuments, bigram=False)

        def append(self, searchWords, numDocuments, bigram):
            for i in range(len(searchWords)):  # traverse
                unigramWords = []
                if bigram:
                    unigramWords.extend(searchWords[i:i + 2])
                else:
                    unigramWords.append(searchWords[i])
                pages = self.YA.fetchSearchResults(unigramWords, numDocuments)
                self.updateByPages(pages, self.YA.updateGenerator(len(searchWords), bigram))  # param

                listMatching = [page for page in pages if 'list' in page]
                if listMatching:  # detect if 'list' exist in the results.
                    for page in listMatching:
                        self[page] += 1  # param
                wordMatching = [page for page in pages if unigramWords[0].lower() == page.lower()]
                if wordMatching:
                    for page in wordMatching:
                        self[page] += self.YA.matchingGenerator(len(searchWords), bigram)  # param

    def updateGenerator(self, length, bigram):
        if bigram:
            return 4 / math.pow(length, 2)
        else:
            return 1 / math.pow(length, 2)


    def matchingGenerator(self, length, bigram):
        if bigram:
            return 65536 / math.pow(2, length) - 1
        else:
            return 65536 / math.pow(2, length - 1) - 1


    def performSearch(self, searchString, numDocuments):

        searchWords = searchString.split()
        pages = self.fetchSearchResults(searchWords, numDocuments)
        # fetch pages.
        pagesDict = self.scoreDict(self)
        pagesDict.updateByPages(pages, 1)  # param

        pagesMatching = [page for page in pages if searchString.lower() == page.lower()]

        if pagesMatching:
            pagesDict[pagesMatching[0]] += 65535  # param
            # find a matching page, ensure first place
        pagesDict.appendByPages(searchWords, numDocuments)

        return pagesDict.items()
        
    def fetchSearchResults(self, foo, numDocuments):
        searchString = ' '.join(foo)
        results = self.searchBackend(searchString, numDocuments)
        pages = []
        for res in results:
            if res[0] not in self.scoredArts:
                self.scoredArts[res[0]] = [res[1], 0.0, searchString]
            pages.append(res[0])
        return pages

    def rankedSearch(self, searchBackend, searchString, maxArticlesPerSearch):
        self.searchBackend = searchBackend
        self.scoredArts = {}
        return self.convertResults(self.performSearch(searchString,maxArticlesPerSearch))
   
    def convertResults(self, pages):
        for page in pages:
            self.scoredArts[page[0]][1] += page[1]
        return sorted(self.scoredArts.items(), key=lambda k: k[1][1], reverse=True)
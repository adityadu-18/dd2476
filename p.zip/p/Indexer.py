from argparse import _AppendAction

from articles.ArticleSearch import ArticleSearch
from articles.ArticleFetcher import ArticleFetcher
from collections import defaultdict
from index.Index import Index
from index.Query import Query
import re

class Indexer:

    def __init__(self, articleResults):
        self.articleResults = articleResults
        self.indexes = dict()  # key: article name, value: index
        self.articleScore = dict()
        for art in articleResults:
            self.articleScore[art[0]] = art[1][1]
            
        print self.articleScore

    def buildIndexes(self, scoreType = 'tf-idf', alpha = 0.5, beta = 0.5):

        for articleResult in self.articleResults:
            articleTitle = articleResult[0]
            article = ArticleFetcher.getParsedArticle(articleTitle)
            index = Index()
            index.buildIndex(article)
            index.computeScores(scoreType, alpha, beta)
            self.indexes[articleTitle] = index

    def search(self, query, numSentences=None, searchType='vector-model', articleRanking=None):
        results = dict()
        scoresOfArticle = defaultdict(int)
        totalWordCount = 0 # Word count in all the articles

        for title, index in self.indexes.viewitems():
            totalWordCount += index.getWordCount()
            for term, weight in query.viewitems():
                # For each article, sum each query's term frequency
                scoresOfArticle[title] += index.getPostings(term).getWordCount()

        for title, index in self.indexes.viewitems():

            scores = defaultdict(int)

            for term, weight in query.viewitems():

                for documentID, entry in index.getPostings(term).postingsEntries.viewitems():
                    if searchType == 'vector-model':
                        scores[documentID] += entry.score * weight
                    elif searchType == 'query-likelihood':
                        if documentID not in scores:
                            scores[documentID] = 1
                        scores[documentID] *= entry.score * weight

            if articleRanking:
                scoreOfArticle = scoresOfArticle[title]
                for documentID, documentScore in scores.viewitems():
                    scores[documentID] *= float(scoreOfArticle) / totalWordCount * self.articleScore[title]

            results[title] = sorted(list(scores.viewitems()), key=lambda tup: tup[1], reverse = True)[0:numSentences]

        return results


    def getContent(self, title):
        if title not in self.indexes:
            return ''
        return self.indexes[title].content


if __name__ == "__main__":
    # Some tests...

    request = "global warming concern"
    query = Query(request.split(" "))
    articleSearch = ArticleSearch()

    # parameters
    searchBackend = articleSearch.searchOS
    searchAlgorithm = 'O'
    maxNumOfArticles = 5
    scoreType = 'tf-idf'
    alpha = 0.5
    beta = 0.5
    searchType = 'query-likelihood' # vector-model, query-likelihood
    articleRanking = True

    articleResults = articleSearch.rankedSearch(searchBackend,searchAlgorithm,request,maxNumOfArticles)
    indexer = Indexer(articleResults)
    indexer.buildIndexes(scoreType, alpha, beta)
    results = indexer.search(query,  None, searchType, articleRanking)

    """
    for articleName, result in results.viewitems() :
        print(str(result[0][0]) + " with score: " + str(result[0][1])) # Sentence id of the best sentence
        print(u"  " + unicode(indexer.getContent(articleName)[result[0][0][0]][result[0][0][1]])) # Best Sentence
    """

    """
    print("Best article found: " + articleResults[0][0])
    result = results[articleResults[0][0]]
    for i in range(len(result)):
        print(u"\n  " + unicode(i+1) + u"\t" + unicode(indexer.getContent(articleResults[0][0])[result[i][0][0]][result[i][0][1]])) # Best Sentence
    """

    mergedResults = []
    for title, articleResult in results.viewitems():
        for element in articleResult:
            mergedResults += [(element[0], element[1], title)]
    sortedResults = sorted(mergedResults, None, key=lambda element: element[1], reverse=True)

    index = 0
    for sentenceResult, score, title in sortedResults:
        index += 1
        print(u"\n  " + unicode(index) + u" " + unicode(score) + u" " + unicode(indexer.getContent(title)[sentenceResult[0]][sentenceResult[1]]))
        if index >= 20:
            exit()






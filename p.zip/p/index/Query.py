

class Query(dict):
    
    def __init__(self, terms, weights=None):
        if not weights:
            weights = [1] * len(terms)
        elif len(terms) != len(weights):
            raise Exception('Weights and terms lists have not the same size')
        super(Query, self).__init__(zip(terms, weights))

    def getTerms(self):
        return self.keys()

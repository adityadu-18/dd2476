from PostingsEntry import PostingsEntry
from collections import defaultdict


class PostingsList:

    def __init__(self, token):
        self.postingsEntries = dict()
        self.paragraphLengths = defaultdict(int) # Counts the number of occurrence (value:int) of the word in the paragraph (key:int)
        self.token = token
        self.wordCount = 0

    def __repr__(self):
        string = u""
        for key, value in self.postingsEntries.viewitems():
            string = string + u" " + str(key) + u" " + str(value) + u"\n"
        return string

    def insert(self, documentID):
        if documentID not in self.postingsEntries:
            self.postingsEntries[documentID] = PostingsEntry(documentID)
        self.postingsEntries[documentID].insert()
        self.paragraphLengths[documentID[0]] += 1
        self.wordCount += 1

    def getWordCount(self, documentID=None):
        if not documentID:
            return self.wordCount
        if isinstance(documentID, int):
            if documentID not in self.paragraphLengths:
                return 0
            return self.paragraphLengths[documentID]
        if documentID not in self.postingsEntries:
            return 0
        return self.postingsEntries[documentID].getWordCount()

    def getDocumentCount(self):
        return self.size()

    def size(self):
        return len(self.postingsEntries)

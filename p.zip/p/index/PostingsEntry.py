class PostingsEntry:

    def __init__(self, documentID):
        self.documentID = documentID
        self.count = 0
        self.score = 0

    def __repr__(self):
        return str('[documentID: ' + str(self.documentID) + ', count: ' + str(self.count) + ', score: ' + str(self.score) + ']')

    def insert(self):
        self.count += 1

    def getWordCount(self):
        return self.count

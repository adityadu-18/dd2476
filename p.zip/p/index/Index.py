from PostingsList import PostingsList
from nltk.tokenize.regexp import RegexpTokenizer
from collections import defaultdict
from math import log, sqrt

class Index:
    def __init__(self):
        self.postingsLists = dict()
        self.wordCount = 0
        self.content = []
        self.documentLengths = defaultdict(int)
        self.paragraphLengths = defaultdict(int)

    def __repr__(self):
        string = u""
        for key, value in self.postingsLists.viewitems():
            string += key + u"\n" + str(value)
        return string

    def insert(self, token, documentID):
        """
        Insert a new element to the index.
        :param token: (st/Users/valentingeffrier/wikipedia-information/index2/Index.pyring) the word to be added
        :param documentID: (tuple) id of the paragraph; id of the sentence
        :param offset: (integer) the offset of the word in the document
        :return:
        """
        if token not in self.postingsLists:
            self.postingsLists[token] = PostingsList(token)
        self.postingsLists[token].insert(documentID)
        self.wordCount += 1

    def getWordCount(self, token=None, documentID=None):
        """
        Get the number of occurrences of a word (or all words) in a document (or the whole corpus).
        :param token: (string) the word - optional
        :param documentID: (tuple) id of the paragraph; id of the sentence
        :return: (integer) the number of occurrences
        """            
        if not token:
            if documentID:
                return self.documentLengths[documentID]
            return self.wordCount
        if token not in self.postingsLists:
            return 0
        return self.postingsLists[token].getWordCount(documentID)

    def getDocumentCount(self, token=None):
        """
        Get the number of document in which the word is.
        :param token: (string) the word
        :return: (integer) the number of documents
        """
        if not token:
            return len(self.documentLengths)
        if token not in self.postingsLists:
            return 0            
        return self.postingsLists[token].getDocumentCount()

    def getPostings(self, token):
        """
        Get the postings corresponding to the word. The returned object is guaranteed not to be None.
        :param token: (string) the word
        :return: (PostingsList) the postings or an empty object if there is no match
        """
        return self.postingsLists.get(token, PostingsList(token))
        
    def buildIndex(self, content):
        """
        Stores the sentences and build the index
        :param content: (nested list) output of the getParsedArticles function
        """
        self.content = content
        tokenizer = RegexpTokenizer(r'\W+', gaps=True)
        for i in range(len(content)):
            if i > 0: # We don't index the first paragraph which is the title
                for j in range(len(content[i])):
                    words = tokenizer.tokenize(content[i][j])
                    for word in words:
                        self.insert(word.lower(), (i, j))
                    self.documentLengths[(i, j)] = len(words)
                    self.paragraphLengths[i] += len(words)


    def search(self, query, searchType='vector-model', numSentences=None):
        tempDict = defaultdict(int)
        for term, weight in query.viewitems():
            for documentID, entry in self.getPostings(term).postingsEntries.viewitems():
                if searchType == 'vector-model':
                    tempDict[documentID] += entry.score * weight
                elif searchType == 'query-likelihood':
                    if documentID not in tempDict:
                        tempDict[documentID] = 1
                    tempDict[documentID] *= entry.score * weight
        results = list(tempDict.viewitems())
        sortedResults = sorted(results, key=lambda tup: tup[1], reverse = True)

        if numSentences:
            bestResults = sortedResults[0:numSentences]
            return bestResults

        return sortedResults


    def getParagraph(self, paragraphId):
        """
        Returns a paragraph as one string
        :param paragraphId:
        :return paragraph: (string) pharagraphs with dots
        """
        par = [item for item in self.content[paragraphId]]
        paragraph = ".".join(par)
        return paragraph

        
    def computeScores(self, scoreType = 'tf-idf', alpha = 0.5, beta = 0.5):
        """
        Computes the score of each word in each sentence
        :param scoreType:
        :param wParagraph: (float) weight of the paragraph's score - used in the smoothed tf-idf algorithm
        :param wSentence: (float) weight of the sentence's score - used in the smoothed tf-idf algorithm
        """
        if scoreType == 'tf-idf':
            for token, postingsList in self.postingsLists.viewitems():
                for sentenceId, postingsEntry in postingsList.postingsEntries.viewitems():
                    postingsEntry.score = 1 + log(postingsEntry.getWordCount())
                    postingsEntry.score *= log(float(self.getDocumentCount())/postingsList.getDocumentCount())
                    postingsEntry.score /= sqrt(self.getWordCount(documentID=sentenceId))
    
        elif scoreType == 'smoothing':
            gamma = 1 - alpha - beta
            for token, postingsList in self.postingsLists.viewitems():

                paragraphFreq = defaultdict(int)
                articleFreq = 0

                for sentenceId, postingsEntry in sorted(postingsList.postingsEntries.viewitems()):
                    postingsEntry.score = alpha*float(postingsEntry.getWordCount())/self.documentLengths[sentenceId]
                    paragraphFreq[sentenceId[0]] += postingsEntry.getWordCount()
                    articleFreq += postingsEntry.getWordCount()

                for sentenceId, postingsEntry in postingsList.postingsEntries.viewitems():
                    postingsEntry.score += beta * float(paragraphFreq[sentenceId[0]])/self.paragraphLengths[sentenceId[0]]
                    postingsEntry.score += gamma * float(articleFreq)/self.wordCount


if __name__ == "__main__":
    # Some tests...

    index = Index()
    index.insert("This", (2,1))
    index.insert("This", (1,5))
    index.insert("is", (1,5))
    index.insert("a", (1,5))
    index.insert("This", (1,4))
    index.insert("is", (1,4))
    index.insert("such", (1,4))
    index.insert("a", (1,4))
    index.insert("great", (1,4))
    index.insert("place", (1,4))
    index.insert("and", (1,4))
    index.insert("a", (1,4))
    index.insert("great", (1,4))

    print(index)

    print(str(index.getWordCount("This", (1,4))))
    print(str(index.getPostings("This").getWordCount((1,4))))

    print(str(index.getDocumentCount("This")))
    print(str(index.getPostings("This").getDocumentCount()))

    print(str(index.getDocumentCount("great")))
    print(str(index.getPostings("great").getDocumentCount()))

    print(str(index.getWordCount("This", 1)))

    print(str(index.getWordCount("This")))
    